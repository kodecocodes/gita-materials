# Clickbait Article Ideas

These articles shouldn't really have any content, but need titles that are irresistible.

- [ ] Top 10 iOS interview questions
- [ ] 8 hottest rumours about Swift 5 - EXPOSED
- [ ] Try these five weird Xcode tips to reduce app bloat
- [ ] Apple to skip iOS 13, eyes a piece of Android's pie
- [ ] 15 ways Android beats iOS into the ground and 7 ways it doesn't
- [ ] I migrated my entire IT department back to Windows XP - and then this happened
- [ ] The Apple announcement that should worry Swift developers
- [ ] iOS 13 to bring back skeuomorphism amidst falling iPhone sales
- [ ] What they don’t want you to know about 5G
