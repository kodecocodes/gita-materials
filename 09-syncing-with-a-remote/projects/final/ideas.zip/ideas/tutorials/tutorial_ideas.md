# Tutorial Ideas

Some tutorial ideas to help us branch out into new areas where no tutorial has gone before:

[ ] Mastering PalmOS
[ ] COBOL: Not just for Y2K anymore
[ ] AppleTalk by Tutorials: Your road to the information superhighway
[ ] Blockchains with BASIC
