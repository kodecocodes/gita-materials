# Ideas for articles for the iOS team

- [ ] How I learnt to stop complaining and embrace the 10k-line view controller
- [ ] The rise of the μFramework
- [ ] The vision framework: Putting the 👁 in iOS
- [ ] You don't understand ML, so don't pretend you do.
- [ ] The return of springs and struts
- [ ] Where have all the indies gone?
