# Platform Ideas

 How can we improve the raywenderlich.com video platform?

- [x] Keyboard shortcuts
- [ ] Integration with Magic Leap
- [x] Jump back/forward
- [x] Remember last watched
- [ ] 360° video experience
