# Live Streaming Ideas

Everybody loves livestreaming. Let's have a piece of that action.

- [ ] Making the perfect cup of coffee - developer-style
- [ ] Mowing the lawn - reaction videos
- [ ] Constructing an ideal speed-garage playlist on Apple Music

