# git-apprentice-web

This is the main website for the Git Apprentice book, from raywenderlich.com.

contact: @crispytwit
